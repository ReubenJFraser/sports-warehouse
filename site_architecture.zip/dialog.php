<!-- dialog.php -->
<div id="formDialog" class="form-dialog">
  <div class="dialog-content">
    <button id="closeDialog" class="close-button" aria-label="Close Form">&times;</button>
    <!-- Full-screen mobile form -->
    <?php include 'contact-form.php'; ?>
  </div>
</div>
