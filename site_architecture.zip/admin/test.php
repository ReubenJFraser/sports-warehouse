<?php
echo "ADMIN PHP WORKS";
