<?php
// /admin/debug/phpinfo.php
phpinfo(INFO_GENERAL | INFO_CONFIGURATION | INFO_MODULES);
