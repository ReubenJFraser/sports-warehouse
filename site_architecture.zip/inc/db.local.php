<?php
// Local development database (Laragon)
return [
    'host'     => 'localhost',
    'dbname'   => 'sports_warehouse',
    'username' => 'root',
    'password' => '',   // Laragon default
    'charset'  => 'utf8mb4'
];



